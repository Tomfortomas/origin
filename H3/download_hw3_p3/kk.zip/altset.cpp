#include "altset.h"
Altset::Altset()
{
    
}
Altset::~Altset()
{
    
}
Altset::Altset(const char *data, int len)
{
    str=data;
    str[len]='\0';
}
void Altset::inverse(int index)
{
    int len=str.length();
    switch(str[len-1-index])
    {
        case '1':{
            str[len-1-index]='0';
            break;
        }
        case '0':{
            str[len-1-index]='1';
            break;
        }
    }
    cout<<"changed str:"<<str<<endl;
}
void Altset::append(int value)
{
    int len=str.length();
    for(int i=len;i>=0;i--)
    {
        str[i+1]=str[i];
    }
    str[0]=value+'0';
    cout<<"changed str:"<<str<<endl;
}
bool Altset::get(int index) const
{
    int len=str.length();
    if(str[len-1-index]=='1')
    {
        return 1;
    }
    return 0;
}
bool Altset::empty() const
{
    if(str[0]=='\0')
    {
        return 1;
    }
    return 0;
}
int Altset::count() const{
    int len=str.length();
    int num=0;
    for(int i=0;i<len;i++)
    {
        if(str[i]=='1')
        {
            num++;
        }
    }
    return num;
}