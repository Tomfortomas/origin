#ifndef __EXAMPLE__
#define __EXAMPLE__
	
class Example {
		
private:
	int data;
	static int num;
	int my_num;
			
public:
	
	Example(int data);
	void getData();
	~Example();

};
		
#endif