#include "add.h"


void ad::UpdateValue()
{
    
    value_ = input1->value() + input2->value();

}
