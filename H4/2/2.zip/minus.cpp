#include "minus.h"

void mi::UpdateValue()
{
    
    value_ = input1->value() - input2->value();

}