#include "Cow.h"

Cow::Cow(string _name,int _l,int _u,int _m)
{
    name=_name;
    l=_l;
    u=_u;
    m=_m;
    meal=0;
    sign=0; 
}