#pragma once
#include <string>
#include <iostream>
using namespace std;
class Cow
{
    public:
    int m;
    int l;
    int u;
    int meal;
    int sign;
    string name;
    Cow(string, int,int,int);
    
};